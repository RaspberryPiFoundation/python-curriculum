#!/bin/python3

print('Hi, I can code in Python!')

print('''
My favourite animals are sheep

 o-###-
   | |   #

I live in Glasgow

   _|_
  |   |
  |#  |____
  |   |    |
  |  #|  # |
 _|___|_#__|_

''')

born = input('What year were you born?')
born = int(born)
age = 2025 - born
print('In the year 2025 you\'ll be', age, 'years old!')