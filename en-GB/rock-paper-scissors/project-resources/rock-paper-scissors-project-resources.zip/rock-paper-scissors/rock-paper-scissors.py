#!/bin/python3

from random import randint

